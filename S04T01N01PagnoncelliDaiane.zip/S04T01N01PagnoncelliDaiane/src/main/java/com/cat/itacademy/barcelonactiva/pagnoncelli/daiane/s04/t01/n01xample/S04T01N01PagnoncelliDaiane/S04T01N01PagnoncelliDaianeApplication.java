package com.cat.itacademy.barcelonactiva.pagnoncelli.daiane.s04.t01.n01xample.S04T01N01PagnoncelliDaiane;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class S04T01N01PagnoncelliDaianeApplication {

	public static void main(String[] args) {
		SpringApplication.run(S04T01N01PagnoncelliDaianeApplication.class, args);
	}

}
