package com.cat.itacademy.barcelonactiva.pagnoncelli.daiane.s04.t01.n01xample.S04T01N01PagnoncelliDaiane;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class S04T01N01PagnoncelliDaianeApplicationTests {

	@Test
	void contextLoads() {
	}

}
