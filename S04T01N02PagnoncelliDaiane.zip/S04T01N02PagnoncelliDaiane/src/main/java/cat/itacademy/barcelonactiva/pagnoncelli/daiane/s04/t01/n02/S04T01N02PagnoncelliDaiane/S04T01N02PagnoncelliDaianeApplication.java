package cat.itacademy.barcelonactiva.pagnoncelli.daiane.s04.t01.n02.S04T01N02PagnoncelliDaiane;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class S04T01N02PagnoncelliDaianeApplication {

	public static void main(String[] args) {
		SpringApplication.run(S04T01N02PagnoncelliDaianeApplication.class, args);
	}

}
