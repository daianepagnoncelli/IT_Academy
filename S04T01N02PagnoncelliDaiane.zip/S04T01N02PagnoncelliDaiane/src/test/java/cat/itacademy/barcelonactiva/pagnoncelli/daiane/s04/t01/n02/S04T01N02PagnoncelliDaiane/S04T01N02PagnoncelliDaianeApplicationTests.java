package cat.itacademy.barcelonactiva.pagnoncelli.daiane.s04.t01.n02.S04T01N02PagnoncelliDaiane;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class S04T01N02PagnoncelliDaianeApplicationTests {

	@Test
	void contextLoads() {
	}

}
